package edu.bu.met.cs665.UtilizingLegacySystems;

public interface CustomerData_USB {
    void printCustomer(int customerId);
    void getCustomer_USB(int customerId);
}
