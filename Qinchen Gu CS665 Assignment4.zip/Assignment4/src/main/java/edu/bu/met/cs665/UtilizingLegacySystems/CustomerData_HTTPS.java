package edu.bu.met.cs665.UtilizingLegacySystems;

public interface CustomerData_HTTPS {
    void printCustomer(int customerId);
    void getCustomer_HTTPS(int customerId);
}
